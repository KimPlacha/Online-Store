import "./Footer.css";

function Footer(){
    return (
        <div className="Footer">
            <h6>A footer will be here</h6>
            <h4>Also a footer</h4>
        </div> // Replace </footer> with </div>

    );
}
<Footer />
 // Add the mi
export default Footer;


